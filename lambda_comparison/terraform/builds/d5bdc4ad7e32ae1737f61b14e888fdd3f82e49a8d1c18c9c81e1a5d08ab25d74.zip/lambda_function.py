def lambda_handler(event, context):
    records = event.get('Records', [])
    message = f"Received {len(records)} from s3"
    return { 
        'message' : message
    }
